// netlify/functions/desk-pin.js
// Save this exact file as: netlify/functions/desk-pin.js
// Then redeploy the site on Netlify.

exports.handler = async function (event) {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: JSON.stringify({ ok: true }) };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ ok: false, error: "Method not allowed" }),
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const pin = (body.pin || "").trim();

    if (!pin) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ ok: false, error: "Pin required" }),
      };
    }

    const expected = process.env.DESK_PIN || "";
    const ok = expected.length > 0 && pin === expected;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ok,
        error: ok ? null : "Wrong pin",
      }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ ok: false, error: err.message || "Server error" }),
    };
  }
};
