// netlify/functions/desk-pin.js
export default async (req) => {
  const headers = { "Content-Type": "application/json" };

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ ok: false, error: "Method not allowed" }), { status: 405, headers });
  }

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    return new Response(JSON.stringify({ ok: false, error: "Server missing service role config" }), { status: 200, headers });
  }

  let body = {};
  try {
    body = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: "Bad body" }), { status: 200, headers });
  }

  const pin = String(body.p_pin || body.pin || "").trim();
  if (!pin) {
    return new Response(JSON.stringify({ ok: false, error: "Missing pin" }), { status: 200, headers });
  }

  try {
    const rpcUrl = url.replace(/\/$/, "") + "/rest/v1/rpc/desk_pin_ok";
    const res = await fetch(rpcUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": key,
        "Authorization": "Bearer " + key
      },
      body: JSON.stringify({ p_pin: pin })
    });

    if (!res.ok) {
      const text = await res.text();
      return new Response(JSON.stringify({ ok: false, error: "RPC failed", detail: text.slice(0, 200) }), { status: 200, headers });
    }

    const data = await res.json();
    return new Response(JSON.stringify({ ok: data === true }), { status: 200, headers });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: "Request failed", detail: String(e).slice(0, 200) }), { status: 200, headers });
  }
};
